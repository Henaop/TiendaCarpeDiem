<?php
session_start();

function conectarDB() {
    $serverName = "DESKTOP-1M1ESO0\\SQLEXPRESS"; // Cambia esto por el nombre de tu servidor
    $database = "admin_carpe"; // Cambia esto por tu base de datos
    $username = "admin_tienda"; // Cambia esto por tu usuario
    $password = "1035973852"; // Cambia esto por tu contraseña

    try {
        $conn = new PDO("sqlsrv:server=$serverName;Database=$database", $username, $password);
        $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        return $conn;
    } catch (PDOException $e) {
        die("Error de conexión: " . $e->getMessage());
    }
}

function crearUsuario($conn, $nombre, $apellido, $documento, $telefono, $direccion) {
    $sql = "INSERT INTO cliente (nombre, apellido, documento, telefono, direccion) VALUES (?, ?, ?, ?, ?)";
    $stmt = $conn->prepare($sql);
    return $stmt->execute([$nombre, $apellido, $documento, $telefono, $direccion]);
}

function leerUsuario($conn) {
    $sql = "SELECT * FROM cliente";
    $stmt = $conn->query($sql);
    return $stmt->fetchAll(PDO::FETCH_ASSOC);
}

function actualizarUsuario($conn, $id, $nombre, $apellido, $documento, $telefono, $direccion, $contrasena) {
    $contrasena_encriptada = password_hash($contrasena, PASSWORD_DEFAULT);
    $sql = "UPDATE cliente SET nombre = ?, apellido = ?, documento = ?, telefono = ?, direccion = ?, contrasena = ? WHERE id = ?";
    $stmt = $conn->prepare($sql);
    return $stmt->execute([$nombre, $apellido, $documento, $telefono, $direccion, $contrasena_encriptada, $id]);
}

function eliminarUsuario($conn, $id) {
    $sql = "DELETE FROM cliente WHERE id = ?";
    $stmt = $conn->prepare($sql);
    return $stmt->execute([$id]);
}

$conn = conectarDB();

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST["accion"])) {
    $accion = $_POST["accion"];
    
    if ($accion == "crear" && isset($_POST["nombre"], $_POST["apellido"], $_POST["documento"], $_POST["telefono"], $_POST["direccion"])) {
        $nombre = $_POST["nombre"];
        $apellido = $_POST["apellido"];
        $documento = $_POST["documento"];
        $telefono = $_POST["telefono"];
        $direccion = $_POST["direccion"];
        
        if (crearUsuario($conn, $nombre, $apellido, $documento, $telefono, $direccion)) {
            echo "Registro exitoso";
        } else {
            echo "Error en el registro";
        }
    } elseif ($accion == "actualizar" && isset($_POST["id"], $_POST["nombre"], $_POST["apellido"], $_POST["documento"], $_POST["telefono"], $_POST["direccion"])) {
        $id = $_POST["id"];
        $nombre = $_POST["nombre"];
        $apellido = $_POST["apellido"];
        $documento = $_POST["documento"];
        $telefono = $_POST["telefono"];
        $direccion = $_POST["direccion"];

        
        if (actualizarUsuario($conn, $id, $nombre, $apellido, $documento, $telefono, $direccion)) {
            echo "Actualización exitosa";
        } else {
            echo "Error en la actualización";
        }
    } elseif ($accion == "eliminar" && isset($_POST["id"])) {
        $id = $_POST["id"];
        
        if (eliminarUsuario($conn, $id)) {
            echo "Eliminación exitosa";
        } else {
            echo "Error en la eliminación";
        }
    }
}

// Asignar $usuarios como array vacío si leerUsuario no devuelve datos
$usuarios = leerUsuario($conn) ?? [];
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Formulario registro</title>
    <style>
        /* Fondo azul cielo */
        body {
            background-color: rgb(81, 159, 159);
            color: black;
        }
        
        /* Estilos para etiquetas en blanco */
        label {
            color: white;
            font-weight: bold;
        }

        /* Estilos para los inputs y botones */
        input[type="text"],
        input[type="submit"] {
            padding: 5px;
            margin: 5px 0;
            font-size: 14px;
        }

        /* Tabla de usuarios */
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
            background-color: white;
        }

        th, td {
            padding: 10px;
            border: 1px solid #000;
            text-align: left;
        }

        th {
            background-color: #4CAF50;
            color: white;
        }

        /* Botones de acción */
        input[type="submit"] {
            background-color: #4CAF50;
            color: white;
            border: none;
            cursor: pointer;
        }

        input[type="submit"]:hover {
            background-color: #45a049;
        }
    </style>
</head>
<body>
    <h2>Formulario de Registro</h2>
    <form action="" method="post">
        <input type="hidden" name="accion" value="crear">
        <label for="nombre">Nombre:</label><br>
        <input type="text" id="nombre" name="nombre" required><br><br>

        <label for="apellido">Apellido:</label><br>
        <input type="text" id="apellido" name="apellido" required><br><br>

        <label for="documento">Documento:</label><br>
        <input type="text" id="documento" name="documento" required><br><br>

        <label for="telefono">Teléfono:</label><br>
        <input type="text" id="telefono" name="telefono" required><br><br>

        <label for="direccion">Dirección:</label><br>
        <input type="text" id="direccion" name="direccion" required><br><br>

        <input type="submit" value="Registrarse">
    </form>

    <h2>Lista de Usuarios</h2>
    <table>
        <tr>
            <th>ID</th>
            <th>Nombre</th>
            <th>Apellido</th>
            <th>Documento</th>
            <th>Teléfono</th>
            <th>Dirección</th>
            <th>Acciones</th>
        </tr>
        <?php foreach ($usuarios as $usuario): ?>
        <tr>
            <td><?php echo htmlspecialchars($usuario['id'], ENT_QUOTES, 'UTF-8'); ?></td>
            <td><?php echo htmlspecialchars($usuario['nombre'], ENT_QUOTES, 'UTF-8'); ?></td>
            <td><?php echo htmlspecialchars($usuario['apellido'], ENT_QUOTES, 'UTF-8'); ?></td>
            <td><?php echo htmlspecialchars($usuario['documento'], ENT_QUOTES, 'UTF-8'); ?></td>
            <td><?php echo htmlspecialchars($usuario['telefono'], ENT_QUOTES, 'UTF-8'); ?></td>
            <td><?php echo htmlspecialchars($usuario['direccion'], ENT_QUOTES, 'UTF-8'); ?></td>
            <td>
                <form action="" method="post" style="display:inline;">
                    <input type="hidden" name="accion" value="eliminar">
                    <input type="hidden" name="id" value="<?php echo htmlspecialchars($usuario['id'], ENT_QUOTES, 'UTF-8'); ?>">
                    <input type="submit" value="Eliminar">
                </form>
                <form action="" method="post" style="display:inline;">
                    <input type="hidden" name="accion" value="actualizar">
                    <input type="hidden" name="id" value="<?php echo htmlspecialchars($usuario['id'], ENT_QUOTES, 'UTF-8'); ?>">
                    <input type="text" name="nombre" value="<?php echo htmlspecialchars($usuario['nombre'], ENT_QUOTES, 'UTF-8'); ?>" required>
                    <input type="text" name="apellido" value="<?php echo htmlspecialchars($usuario['apellido'], ENT_QUOTES, 'UTF-8'); ?>" required>
                    <input type="text" name="documento" value="<?php echo htmlspecialchars($usuario['documento'], ENT_QUOTES, 'UTF-8'); ?>" required>
                    <input type="text" name="telefono" value="<?php echo htmlspecialchars($usuario['telefono'], ENT_QUOTES, 'UTF-8'); ?>" required>
                    <input type="text" name="direccion" value="<?php echo htmlspecialchars($usuario['direccion'], ENT_QUOTES, 'UTF-8'); ?>" required>
                    <input type="submit" value="Actualizar">
                </form>
            </td>
        </tr>
        <?php endforeach; ?>
    </table>
</body>
</html>
<?php
$conn = null; // Cerrar la conexión
?>
