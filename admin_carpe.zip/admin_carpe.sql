﻿
Microsoft Visual Studio Solution File, Format Version 12.00
# SQL Server Management Studio Solution File, Format Version 20.00
VisualStudioVersion = 15.0.28307.421
MinimumVisualStudioVersion = 10.0.40219.1
Global
	GlobalSection(SolutionConfigurationPlatforms) = preSolution
		Default|Default = Default|Default
	EndGlobalSection
	GlobalSection(ProjectConfigurationPlatforms) = postSolution
		{F9E626E5-9DEF-46E9-8A4E-2CDA584A3F37}.Default|Default.ActiveCfg = Default
	EndGlobalSection
	GlobalSection(SolutionProperties) = preSolution
		HideSolutionNode = FALSE
	EndGlobalSection
	GlobalSection(ExtensibilityGlobals) = postSolution
		SolutionGuid = {8F61B81A-38B1-4FBB-9D0C-22406C75BA96}
	EndGlobalSection
EndGlobal
